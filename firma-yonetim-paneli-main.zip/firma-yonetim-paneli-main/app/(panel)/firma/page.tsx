"use client";

import { useEffect, useState } from "react";
import { Building2, Check } from "lucide-react";
import { etiketSinifi, girdiSinifi } from "@/lib/format";

type FormVerisi = { ad: string; adres: string; telefon: string; vergiNo: string };

const bosForm: FormVerisi = { ad: "", adres: "", telefon: "", vergiNo: "" };

export default function FirmaSayfasi() {
  const [form, setForm] = useState<FormVerisi>(bosForm);
  const [yukleniyor, setYukleniyor] = useState(true);
  const [kaydediliyor, setKaydediliyor] = useState(false);
  const [hata, setHata] = useState("");
  const [kaydedildi, setKaydedildi] = useState(false);

  useEffect(() => {
    fetch("/api/firma")
      .then(async (yanit) => {
        if (yanit.status === 404) return null; // henüz kayıt yok, boş form
        if (!yanit.ok) throw new Error();
        return yanit.json();
      })
      .then((firma) => {
        if (firma) {
          setForm({
            ad: firma.ad ?? "",
            adres: firma.adres ?? "",
            telefon: firma.telefon ?? "",
            vergiNo: firma.vergiNo ?? "",
          });
        }
      })
      .catch(() => setHata("Firma bilgileri yüklenemedi"))
      .finally(() => setYukleniyor(false));
  }, []);

  async function kaydet(e: React.FormEvent) {
    e.preventDefault();
    setKaydediliyor(true);
    setHata("");
    setKaydedildi(false);

    const govde = {
      ad: form.ad.trim(),
      adres: form.adres.trim() || null,
      telefon: form.telefon.trim() || null,
      vergiNo: form.vergiNo.trim() || null,
    };

    try {
      const yanit = await fetch("/api/firma", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(govde),
      });
      if (!yanit.ok) {
        const j = await yanit.json().catch(() => null);
        setHata(j?.hata ?? "Kaydetme başarısız oldu");
        return;
      }
      setKaydedildi(true);
      setTimeout(() => setKaydedildi(false), 3000);
    } catch {
      setHata("Sunucuya ulaşılamadı");
    } finally {
      setKaydediliyor(false);
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-semibold">Firma Bilgileri</h1>
      <p className="mt-1 text-sm text-slate-500">
        Bu bilgiler ileride raporlarda ve belgelerde kullanılacak
      </p>

      <div className="mt-6 max-w-xl rounded-xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="mb-5 flex items-center gap-3">
          <div className="rounded-lg bg-sky-100 p-2.5 text-sky-600">
            <Building2 size={22} />
          </div>
          <div>
            <h2 className="font-semibold text-slate-800">Firma Kartı</h2>
            <p className="text-xs text-slate-400">Tek kayıt — değişiklikler hemen geçerli olur</p>
          </div>
        </div>

        {yukleniyor ? (
          <p className="py-6 text-sm text-slate-500">Yükleniyor…</p>
        ) : (
          <form onSubmit={kaydet} className="space-y-4">
            <div>
              <label htmlFor="ad" className={etiketSinifi}>
                Firma Adı <span className="text-red-500">*</span>
              </label>
              <input
                id="ad"
                required
                value={form.ad}
                onChange={(e) => setForm({ ...form, ad: e.target.value })}
                className={girdiSinifi}
              />
            </div>

            <div>
              <label htmlFor="adres" className={etiketSinifi}>
                Adres
              </label>
              <textarea
                id="adres"
                rows={2}
                value={form.adres}
                onChange={(e) => setForm({ ...form, adres: e.target.value })}
                className={girdiSinifi}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="telefon" className={etiketSinifi}>
                  Telefon
                </label>
                <input
                  id="telefon"
                  type="tel"
                  value={form.telefon}
                  onChange={(e) => setForm({ ...form, telefon: e.target.value })}
                  className={girdiSinifi}
                />
              </div>
              <div>
                <label htmlFor="vergiNo" className={etiketSinifi}>
                  Vergi No
                </label>
                <input
                  id="vergiNo"
                  value={form.vergiNo}
                  onChange={(e) => setForm({ ...form, vergiNo: e.target.value })}
                  className={girdiSinifi}
                />
              </div>
            </div>

            {hata && (
              <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">{hata}</p>
            )}

            <div className="flex items-center justify-end gap-3 pt-1">
              {kaydedildi && (
                <span className="flex items-center gap-1.5 text-sm font-medium text-emerald-600">
                  <Check size={16} />
                  Kaydedildi
                </span>
              )}
              <button
                type="submit"
                disabled={kaydediliyor}
                className="rounded-lg bg-sky-600 px-5 py-2 text-sm font-medium text-white transition-colors hover:bg-sky-700 disabled:opacity-60"
              >
                {kaydediliyor ? "Kaydediliyor…" : "Kaydet"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
