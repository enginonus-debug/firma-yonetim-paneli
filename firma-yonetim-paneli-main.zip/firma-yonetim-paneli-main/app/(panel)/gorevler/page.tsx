"use client";

import { useCallback, useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, Pencil, Plus, Trash2 } from "lucide-react";
import Modal from "@/components/Modal";
import { etiketSinifi, girdiSinifi, tarihGoster } from "@/lib/format";

type Gorev = {
  id: number;
  baslik: string;
  aciklama: string | null;
  durum: string;
  oncelik: string | null;
  baslangic: string | null;
  bitis: string | null;
  calisanId: number | null;
  makineId: number | null;
  calisan: { id: number; adSoyad: string } | null;
  makine: { id: number; ad: string } | null;
};

type Secenek = { id: number; ad: string };

type FormVerisi = {
  baslik: string;
  aciklama: string;
  calisanId: string;
  makineId: string;
  oncelik: string;
  durum: string;
  baslangic: string;
  bitis: string;
};

const bosForm: FormVerisi = {
  baslik: "",
  aciklama: "",
  calisanId: "",
  makineId: "",
  oncelik: "normal",
  durum: "bekliyor",
  baslangic: "",
  bitis: "",
};

const kolonlar = [
  { durum: "bekliyor", baslik: "Bekliyor", ust: "border-t-slate-400" },
  { durum: "devam_ediyor", baslik: "Devam Ediyor", ust: "border-t-sky-500" },
  { durum: "tamamlandi", baslik: "Tamamlandı", ust: "border-t-emerald-500" },
];

const oncelikler: Record<string, { etiket: string; sinif: string }> = {
  yuksek: { etiket: "Yüksek", sinif: "bg-red-100 text-red-700" },
  normal: { etiket: "Normal", sinif: "bg-sky-100 text-sky-700" },
  dusuk: { etiket: "Düşük", sinif: "bg-slate-100 text-slate-600" },
};

export default function GorevlerSayfasi() {
  const [gorevler, setGorevler] = useState<Gorev[]>([]);
  const [calisanlar, setCalisanlar] = useState<Secenek[]>([]);
  const [makineler, setMakineler] = useState<Secenek[]>([]);
  const [yukleniyor, setYukleniyor] = useState(true);
  const [hata, setHata] = useState("");

  const [form, setForm] = useState<FormVerisi | null>(null);
  const [duzenlenen, setDuzenlenen] = useState<Gorev | null>(null);
  const [formHata, setFormHata] = useState("");
  const [kaydediliyor, setKaydediliyor] = useState(false);

  const yukle = useCallback(async () => {
    setHata("");
    try {
      const [gYanit, cYanit, mYanit] = await Promise.all([
        fetch("/api/gorevler"),
        fetch("/api/calisanlar?aktif=true"),
        fetch("/api/makineler"),
      ]);
      if (!gYanit.ok || !cYanit.ok || !mYanit.ok) throw new Error();
      setGorevler(await gYanit.json());
      const cs: { id: number; adSoyad: string }[] = await cYanit.json();
      setCalisanlar(cs.map((c) => ({ id: c.id, ad: c.adSoyad })));
      const ms: { id: number; ad: string }[] = await mYanit.json();
      setMakineler(ms.map((m) => ({ id: m.id, ad: m.ad })));
    } catch {
      setHata("Görevler yüklenemedi");
    } finally {
      setYukleniyor(false);
    }
  }, []);

  useEffect(() => {
    yukle();
  }, [yukle]);

  function yeniAc() {
    setDuzenlenen(null);
    setForm(bosForm);
    setFormHata("");
  }

  function duzenleAc(g: Gorev) {
    setDuzenlenen(g);
    setForm({
      baslik: g.baslik,
      aciklama: g.aciklama ?? "",
      calisanId: g.calisanId ? String(g.calisanId) : "",
      makineId: g.makineId ? String(g.makineId) : "",
      oncelik: g.oncelik ?? "normal",
      durum: g.durum,
      baslangic: g.baslangic?.slice(0, 10) ?? "",
      bitis: g.bitis?.slice(0, 10) ?? "",
    });
    setFormHata("");
  }

  function kapat() {
    setForm(null);
    setDuzenlenen(null);
  }

  async function kaydet(e: React.FormEvent) {
    e.preventDefault();
    if (!form) return;
    setKaydediliyor(true);
    setFormHata("");

    const govde = {
      baslik: form.baslik.trim(),
      aciklama: form.aciklama.trim() || null,
      calisanId: form.calisanId ? Number(form.calisanId) : null,
      makineId: form.makineId ? Number(form.makineId) : null,
      oncelik: form.oncelik,
      durum: form.durum,
      baslangic: form.baslangic || null,
      bitis: form.bitis || null,
    };

    try {
      const yanit = await fetch(
        duzenlenen ? `/api/gorevler/${duzenlenen.id}` : "/api/gorevler",
        {
          method: duzenlenen ? "PUT" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(govde),
        }
      );
      if (!yanit.ok) {
        const j = await yanit.json().catch(() => null);
        setFormHata(j?.hata ?? "Kayıt başarısız oldu");
        return;
      }
      kapat();
      yukle();
    } catch {
      setFormHata("Sunucuya ulaşılamadı");
    } finally {
      setKaydediliyor(false);
    }
  }

  // Kanban taşıma: iyimser güncelle, hata olursa geri yükle
  async function tasi(id: number, durum: string) {
    const eski = gorevler;
    setGorevler((liste) => liste.map((g) => (g.id === id ? { ...g, durum } : g)));
    const yanit = await fetch(`/api/gorevler/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ durum }),
    });
    if (!yanit.ok) {
      setGorevler(eski);
      setHata("Görev taşınamadı");
    }
  }

  async function sil(g: Gorev) {
    if (!window.confirm(`"${g.baslik}" görevi silinsin mi?`)) return;
    const yanit = await fetch(`/api/gorevler/${g.id}`, { method: "DELETE" });
    if (yanit.ok) yukle();
    else setHata("Silme başarısız oldu");
  }

  const sira = kolonlar.map((k) => k.durum);

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">Görevler</h1>
          <p className="mt-1 text-sm text-slate-500">
            Görevleri sürükleyerek veya ok butonlarıyla taşıyın
          </p>
        </div>
        <button
          onClick={yeniAc}
          className="flex items-center gap-2 rounded-lg bg-sky-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-sky-700"
        >
          <Plus size={17} />
          Yeni Görev
        </button>
      </div>

      {hata && (
        <p className="mt-4 rounded-lg bg-red-50 px-4 py-3 text-sm text-red-600">{hata}</p>
      )}

      {yukleniyor ? (
        <p className="mt-6 text-slate-500">Yükleniyor…</p>
      ) : (
        <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-3">
          {kolonlar.map((kolon) => {
            const kolonGorevleri = gorevler.filter((g) => g.durum === kolon.durum);
            return (
              <div
                key={kolon.durum}
                onDragOver={(e) => e.preventDefault()}
                onDrop={(e) => {
                  const id = Number(e.dataTransfer.getData("text/plain"));
                  if (id) tasi(id, kolon.durum);
                }}
                className={`rounded-xl border border-slate-200 border-t-4 bg-slate-50 ${kolon.ust}`}
              >
                <div className="flex items-center justify-between px-4 py-3">
                  <h2 className="text-sm font-semibold text-slate-700">{kolon.baslik}</h2>
                  <span className="rounded-full bg-white px-2.5 py-0.5 text-xs font-medium text-slate-500 ring-1 ring-slate-200">
                    {kolonGorevleri.length}
                  </span>
                </div>

                <div className="flex min-h-40 flex-col gap-2.5 p-3 pt-0">
                  {kolonGorevleri.length === 0 && (
                    <p className="rounded-lg border-2 border-dashed border-slate-200 px-3 py-6 text-center text-xs text-slate-400">
                      Görev yok
                    </p>
                  )}
                  {kolonGorevleri.map((g) => {
                    const konum = sira.indexOf(g.durum);
                    return (
                      <div
                        key={g.id}
                        draggable
                        onDragStart={(e) =>
                          e.dataTransfer.setData("text/plain", String(g.id))
                        }
                        className="group cursor-grab rounded-lg border border-slate-200 bg-white p-3 shadow-sm transition-shadow hover:shadow-md active:cursor-grabbing"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <p
                            className={`text-sm font-medium ${
                              g.durum === "tamamlandi"
                                ? "text-slate-400 line-through"
                                : "text-slate-800"
                            }`}
                          >
                            {g.baslik}
                          </p>
                          {g.oncelik && oncelikler[g.oncelik] && (
                            <span
                              className={`shrink-0 rounded-full px-2 py-0.5 text-[11px] font-medium ${oncelikler[g.oncelik].sinif}`}
                            >
                              {oncelikler[g.oncelik].etiket}
                            </span>
                          )}
                        </div>

                        {g.aciklama && (
                          <p className="mt-1 line-clamp-2 text-xs text-slate-500">
                            {g.aciklama}
                          </p>
                        )}

                        <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1 text-xs text-slate-400">
                          {g.calisan && <span>👤 {g.calisan.adSoyad}</span>}
                          {g.makine && <span>⚙️ {g.makine.ad}</span>}
                          {g.bitis && <span>📅 {tarihGoster(g.bitis)}</span>}
                        </div>

                        <div className="mt-2 flex items-center justify-between border-t border-slate-100 pt-2">
                          <div className="flex gap-1">
                            <button
                              onClick={() => konum > 0 && tasi(g.id, sira[konum - 1])}
                              disabled={konum === 0}
                              title="Geri taşı"
                              className="rounded p-1 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 disabled:opacity-30"
                            >
                              <ChevronLeft size={15} />
                            </button>
                            <button
                              onClick={() =>
                                konum < sira.length - 1 && tasi(g.id, sira[konum + 1])
                              }
                              disabled={konum === sira.length - 1}
                              title="İleri taşı"
                              className="rounded p-1 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700 disabled:opacity-30"
                            >
                              <ChevronRight size={15} />
                            </button>
                          </div>
                          <div className="flex gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                            <button
                              onClick={() => duzenleAc(g)}
                              title="Düzenle"
                              className="rounded p-1 text-slate-400 transition-colors hover:bg-slate-100 hover:text-slate-700"
                            >
                              <Pencil size={14} />
                            </button>
                            <button
                              onClick={() => sil(g)}
                              title="Sil"
                              className="rounded p-1 text-slate-400 transition-colors hover:bg-red-50 hover:text-red-600"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {form && (
        <Modal
          baslik={duzenlenen ? "Görevi Düzenle" : "Yeni Görev"}
          kapat={kapat}
          genis
        >
          <form onSubmit={kaydet} className="space-y-4">
            <div>
              <label htmlFor="baslik" className={etiketSinifi}>
                Başlık <span className="text-red-500">*</span>
              </label>
              <input
                id="baslik"
                required
                value={form.baslik}
                onChange={(e) => setForm({ ...form, baslik: e.target.value })}
                className={girdiSinifi}
                placeholder="Örn: 20 adet sandalye iskeleti kesimi"
              />
            </div>

            <div>
              <label htmlFor="aciklama" className={etiketSinifi}>
                Açıklama
              </label>
              <textarea
                id="aciklama"
                rows={2}
                value={form.aciklama}
                onChange={(e) => setForm({ ...form, aciklama: e.target.value })}
                className={girdiSinifi}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="calisanId" className={etiketSinifi}>
                  Çalışan
                </label>
                <select
                  id="calisanId"
                  value={form.calisanId}
                  onChange={(e) => setForm({ ...form, calisanId: e.target.value })}
                  className={girdiSinifi}
                >
                  <option value="">Atanmadı</option>
                  {calisanlar.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.ad}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="makineId" className={etiketSinifi}>
                  Makine
                </label>
                <select
                  id="makineId"
                  value={form.makineId}
                  onChange={(e) => setForm({ ...form, makineId: e.target.value })}
                  className={girdiSinifi}
                >
                  <option value="">Yok</option>
                  {makineler.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.ad}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="oncelik" className={etiketSinifi}>
                  Öncelik
                </label>
                <select
                  id="oncelik"
                  value={form.oncelik}
                  onChange={(e) => setForm({ ...form, oncelik: e.target.value })}
                  className={girdiSinifi}
                >
                  <option value="dusuk">Düşük</option>
                  <option value="normal">Normal</option>
                  <option value="yuksek">Yüksek</option>
                </select>
              </div>
              <div>
                <label htmlFor="durum" className={etiketSinifi}>
                  Durum
                </label>
                <select
                  id="durum"
                  value={form.durum}
                  onChange={(e) => setForm({ ...form, durum: e.target.value })}
                  className={girdiSinifi}
                >
                  {kolonlar.map((k) => (
                    <option key={k.durum} value={k.durum}>
                      {k.baslik}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label htmlFor="baslangic" className={etiketSinifi}>
                  Başlangıç
                </label>
                <input
                  id="baslangic"
                  type="date"
                  value={form.baslangic}
                  onChange={(e) => setForm({ ...form, baslangic: e.target.value })}
                  className={girdiSinifi}
                />
              </div>
              <div>
                <label htmlFor="bitis" className={etiketSinifi}>
                  Bitiş
                </label>
                <input
                  id="bitis"
                  type="date"
                  value={form.bitis}
                  onChange={(e) => setForm({ ...form, bitis: e.target.value })}
                  className={girdiSinifi}
                />
              </div>
            </div>

            {formHata && (
              <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">{formHata}</p>
            )}

            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={kapat}
                className="rounded-lg border border-slate-300 px-4 py-2 text-sm text-slate-600 transition-colors hover:bg-slate-50"
              >
                Vazgeç
              </button>
              <button
                type="submit"
                disabled={kaydediliyor}
                className="rounded-lg bg-sky-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-sky-700 disabled:opacity-60"
              >
                {kaydediliyor ? "Kaydediliyor…" : duzenlenen ? "Güncelle" : "Ekle"}
              </button>
            </div>
          </form>
        </Modal>
      )}
    </div>
  );
}
