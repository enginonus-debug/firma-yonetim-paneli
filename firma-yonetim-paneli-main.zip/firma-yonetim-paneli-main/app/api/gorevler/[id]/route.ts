import { prisma } from "@/lib/db";
import { yetki } from "@/lib/yetki";
import { govdeDogrula, hata, idAl, ok, prismaHataKodu } from "@/lib/api";
import { gorevDurumSemasi, gorevGuncelleSemasi } from "@/lib/semalar";
import { degisiklikOzeti, denetimKaydet } from "@/lib/denetim";

type Baglam = { params: Promise<{ id: string }> };

const iliskiler = {
  calisan: { select: { id: true, adSoyad: true } },
  makine: { select: { id: true, ad: true } },
};

// GET /api/gorevler/:id — görev detayı
export async function GET(_istek: Request, { params }: Baglam) {
  const y = await yetki("gorevler", "okuma");
  if (y.yanit) return y.yanit;
  const firmaId = y.firmaId;

  const id = idAl((await params).id);
  if (!id) return hata("Geçersiz id");

  const gorev = await prisma.gorev.findFirst({
    where: { id, firmaId: firmaId },
    include: iliskiler,
  });
  if (!gorev) return hata("Görev bulunamadı", 404);
  return ok(gorev);
}

// PUT /api/gorevler/:id — görevi günceller
export async function PUT(istek: Request, { params }: Baglam) {
  const y = await yetki("gorevler", "yazma");
  if (y.yanit) return y.yanit;
  const firmaId = y.firmaId;

  const id = idAl((await params).id);
  if (!id) return hata("Geçersiz id");

  const sonuc = await govdeDogrula(istek, gorevGuncelleSemasi);
  if (sonuc.yanit) return sonuc.yanit;

  const eski = await prisma.gorev.findFirst({ where: { id, firmaId: firmaId } });
  if (!eski) return hata("Görev bulunamadı", 404);

  try {
    const gorev = await prisma.gorev.update({
      where: { id, firmaId: firmaId },
      data: sonuc.veri,
      include: iliskiler,
    });
    await denetimKaydet({
      kullanici: y.kullanici,
      ekran: "gorevler",
      islem: "guncelleme",
      hedefTip: "Görev",
      hedefId: gorev.id,
      hedefAd: gorev.baslik,
      detay: degisiklikOzeti(eski, sonuc.veri),
    });
    return ok(gorev);
  } catch (e) {
    if (prismaHataKodu(e) === "P2025") return hata("Görev bulunamadı", 404);
    throw e;
  }
}

// PATCH /api/gorevler/:id — sadece durum değiştirir (kanban sürükle-bırak için)
export async function PATCH(istek: Request, { params }: Baglam) {
  const y = await yetki("gorevler", "yazma");
  if (y.yanit) return y.yanit;
  const firmaId = y.firmaId;

  const id = idAl((await params).id);
  if (!id) return hata("Geçersiz id");

  const sonuc = await govdeDogrula(istek, gorevDurumSemasi);
  if (sonuc.yanit) return sonuc.yanit;

  const eski = await prisma.gorev.findFirst({ where: { id, firmaId: firmaId } });
  if (!eski) return hata("Görev bulunamadı", 404);

  try {
    const gorev = await prisma.gorev.update({
      where: { id, firmaId: firmaId },
      data: { durum: sonuc.veri.durum },
      include: iliskiler,
    });
    await denetimKaydet({
      kullanici: y.kullanici,
      ekran: "gorevler",
      islem: "guncelleme",
      hedefTip: "Görev",
      hedefId: gorev.id,
      hedefAd: gorev.baslik,
      detay: degisiklikOzeti(eski, { durum: sonuc.veri.durum }),
    });
    return ok(gorev);
  } catch (e) {
    if (prismaHataKodu(e) === "P2025") return hata("Görev bulunamadı", 404);
    throw e;
  }
}

// DELETE /api/gorevler/:id — görevi siler
export async function DELETE(_istek: Request, { params }: Baglam) {
  const y = await yetki("gorevler", "yazma");
  if (y.yanit) return y.yanit;
  const firmaId = y.firmaId;

  const id = idAl((await params).id);
  if (!id) return hata("Geçersiz id");

  const eski = await prisma.gorev.findFirst({ where: { id, firmaId: firmaId } });
  if (!eski) return hata("Görev bulunamadı", 404);

  try {
    await prisma.gorev.delete({ where: { id, firmaId: firmaId } });
    await denetimKaydet({
      kullanici: y.kullanici,
      ekran: "gorevler",
      islem: "silme",
      hedefTip: "Görev",
      hedefId: id,
      hedefAd: eski.baslik,
    });
    return ok({ mesaj: "Görev silindi" });
  } catch (e) {
    if (prismaHataKodu(e) === "P2025") return hata("Görev bulunamadı", 404);
    throw e;
  }
}
