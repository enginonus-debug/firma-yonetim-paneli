import { prisma } from "@/lib/db";
import { yetki } from "@/lib/yetki";
import { govdeDogrula, ok } from "@/lib/api";
import { gorevSemasi } from "@/lib/semalar";
import { degisiklikOzeti, denetimKaydet } from "@/lib/denetim";

// GET /api/gorevler?durum=&calisanId=&makineId= — görev listesi (kanban için)
export async function GET(istek: Request) {
  const y = await yetki("gorevler", "okuma");
  if (y.yanit) return y.yanit;
  const firmaId = y.firmaId;

  const url = new URL(istek.url);
  const durum = url.searchParams.get("durum");
  const calisanId = Number(url.searchParams.get("calisanId")) || undefined;
  const makineId = Number(url.searchParams.get("makineId")) || undefined;

  const gorevler = await prisma.gorev.findMany({
    where: {
      firmaId: firmaId,
      ...(durum ? { durum } : {}),
      ...(calisanId ? { calisanId } : {}),
      ...(makineId ? { makineId } : {}),
    },
    include: {
      calisan: { select: { id: true, adSoyad: true } },
      makine: { select: { id: true, ad: true } },
    },
    orderBy: { olusturma: "desc" },
  });
  return ok(gorevler);
}

// POST /api/gorevler — yeni görev oluşturur
export async function POST(istek: Request) {
  const y = await yetki("gorevler", "yazma");
  if (y.yanit) return y.yanit;
  const firmaId = y.firmaId;

  const sonuc = await govdeDogrula(istek, gorevSemasi);
  if (sonuc.yanit) return sonuc.yanit;

  const gorev = await prisma.gorev.create({
    data: { ...sonuc.veri, firmaId: firmaId },
    include: {
      calisan: { select: { id: true, adSoyad: true } },
      makine: { select: { id: true, ad: true } },
    },
  });
  await denetimKaydet({
    kullanici: y.kullanici,
    ekran: "gorevler",
    islem: "ekleme",
    hedefTip: "Görev",
    hedefId: gorev.id,
    hedefAd: gorev.baslik,
    detay: degisiklikOzeti(null, sonuc.veri),
  });
  return ok(gorev, 201);
}
