import bcrypt from "bcryptjs";
import { prisma } from "@/lib/db";
import { adminYetki } from "@/lib/yetki";
import { govdeDogrula, hata, idAl, ok } from "@/lib/api";
import { kullaniciGuncelleSemasi } from "@/lib/semalar";
import { degisiklikOzeti, denetimKaydet } from "@/lib/denetim";

// PATCH /api/kullanicilar/:id — izin/aktiflik/ad/şifre güncelle (firma admini).
// Yalnızca kendi firmasının rol=kullanici hesapları değiştirilebilir;
// admin kendi hesabını veya başka adminleri buradan değiştiremez.
export async function PATCH(istek: Request, baglam: { params: Promise<{ id: string }> }) {
  const y = await adminYetki();
  if (y.yanit) return y.yanit;

  const { id: idParam } = await baglam.params;
  const id = idAl(idParam);
  if (!id) return hata("Geçersiz kullanıcı id'si");

  const hedef = await prisma.kullanici.findUnique({ where: { id } });
  if (!hedef || hedef.firmaId !== y.firmaId || hedef.rol !== "kullanici") {
    return hata("Kullanıcı bulunamadı", 404);
  }

  const sonuc = await govdeDogrula(istek, kullaniciGuncelleSemasi);
  if (sonuc.yanit) return sonuc.yanit;
  const { sifre, ...alanlar } = sonuc.veri;

  const kullanici = await prisma.kullanici.update({
    where: { id },
    data: {
      ...alanlar,
      ...(sifre ? { sifreHash: await bcrypt.hash(sifre, 10) } : {}),
    },
    select: { id: true, email: true, adSoyad: true, rol: true, izinler: true, aktif: true },
  });
  await denetimKaydet({
    kullanici: y.kullanici,
    ekran: "kullanicilar",
    islem: "guncelleme",
    hedefTip: "Kullanıcı",
    hedefId: kullanici.id,
    hedefAd: kullanici.email,
    detay: degisiklikOzeti(hedef, { ...alanlar, ...(sifre ? { sifre } : {}) }),
  });
  return ok(kullanici);
}
