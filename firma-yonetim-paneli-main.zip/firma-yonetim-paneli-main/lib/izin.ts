// Yıllık ücretli izin hakkı — 4857 sayılı İş Kanunu md. 53
//
// Hizmet süresine göre:
//   1 yıldan 5 yıla kadar (5 yıl dâhil)  → 14 gün
//   5 yıldan fazla, 15 yıldan az         → 20 gün
//   15 yıl (dâhil) ve üzeri              → 26 gün
// 50 yaş ve üzeri ile 18 yaşından küçük çalışanlarda alt sınır 20 gündür.
// 1 yılını doldurmamış çalışanın henüz izin hakkı doğmaz (0 gün).

// İki tarih arasındaki tam yıl sayısı (yıldönümü henüz gelmediyse bir eksik)
export function tamYil(baslangic: Date, referans: Date): number {
  let yil = referans.getUTCFullYear() - baslangic.getUTCFullYear();
  const yildonumuGecti =
    referans.getUTCMonth() > baslangic.getUTCMonth() ||
    (referans.getUTCMonth() === baslangic.getUTCMonth() &&
      referans.getUTCDate() >= baslangic.getUTCDate());
  if (!yildonumuGecti) yil -= 1;
  return yil;
}

// İçinde bulunulan izin yılının başlangıcı: işe girişin son yıldönümü.
// Kullanılan izin bu tarihten itibaren sayılır; her yıldönümünde hak yenilenir.
export function izinYiliBaslangici(iseBaslama: Date, referans: Date): Date {
  const yil = referans.getUTCFullYear();
  const buYilki = new Date(
    Date.UTC(yil, iseBaslama.getUTCMonth(), iseBaslama.getUTCDate())
  );
  if (buYilki <= referans) return buYilki;
  return new Date(Date.UTC(yil - 1, iseBaslama.getUTCMonth(), iseBaslama.getUTCDate()));
}

// İzin hakkı gün sayısı; işe başlama tarihi yoksa hesaplanamaz (null)
export function yillikIzinHakki(
  iseBaslama: Date | null,
  dogumTarihi: Date | null,
  referans: Date
): number | null {
  if (!iseBaslama) return null;

  const hizmetYili = tamYil(iseBaslama, referans);
  if (hizmetYili < 1) return 0;

  let hak: number;
  if (hizmetYili <= 5) hak = 14;
  else if (hizmetYili < 15) hak = 20;
  else hak = 26;

  if (dogumTarihi) {
    const yas = tamYil(dogumTarihi, referans);
    if (yas >= 50 || yas < 18) hak = Math.max(hak, 20);
  }
  return hak;
}
