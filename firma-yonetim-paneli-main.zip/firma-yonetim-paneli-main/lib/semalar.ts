import { z } from "zod";

// ---- Ortak parçalar ----
const tarihStr = z
  .string()
  .regex(/^\d{4}-\d{2}-\d{2}$/, "YYYY-AA-GG biçiminde olmalı");
const saatStr = z.string().regex(/^\d{2}:\d{2}$/, "SS:DD biçiminde olmalı");
const idNo = z.number().int().positive();

// ---- Firma ----
export const firmaSemasi = z.object({
  ad: z.string().min(1, "Firma adı zorunlu"),
  adres: z.string().nullish(),
  telefon: z.string().nullish(),
  vergiNo: z.string().nullish(),
});

// ---- Çalışan ----
// Başında 0 olmadan 10 haneli telefon (ör: 5321234567)
const telefon10 = /^[1-9]\d{9}$/;
// Kayıtlar tek biçim görünsün diye ad ve pozisyon Türkçe büyük harfe çevrilir
const buyukHarf = (s: string) => s.toLocaleUpperCase("tr-TR");

const calisanTaban = z.object({
  adSoyad: z.string().min(1, "Ad soyad zorunlu").transform(buyukHarf),
  tcKimlikNo: z
    .string({ error: "TC kimlik no zorunlu" })
    .regex(/^\d{11}$/, "TC kimlik no 11 haneli rakam olmalı"),
  dogumTarihi: z.coerce.date({ error: "Doğum tarihi zorunlu" }),
  pozisyon: z
    .string({ error: "Pozisyon zorunlu" })
    .min(1, "Pozisyon zorunlu")
    .transform(buyukHarf),
  telefon: z
    .string({ error: "Telefon zorunlu" })
    .regex(telefon10, "Telefon başında 0 olmadan 10 haneli olmalı"),
  adres: z.string({ error: "İkamet bilgisi zorunlu" }).min(1, "İkamet bilgisi zorunlu"),
  acilTelefon: z
    .string({ error: "Acil durumda aranacak yakın numarası zorunlu" })
    .regex(telefon10, "Yakın numarası başında 0 olmadan 10 haneli olmalı"),
  foto: z
    .string()
    .startsWith("data:image/", "Geçersiz görsel biçimi")
    .max(700_000, "Fotoğraf çok büyük")
    .nullish(),
  iseBaslama: z.coerce.date({ error: "İşe başlama tarihi zorunlu" }),
  istenAyrilma: z.coerce.date().nullish(),
  maas: z.coerce.number().nonnegative("Maaş negatif olamaz").nullish(),
  engelli: z.boolean().optional(),
  engelDurumu: z.string().nullish(),
  aktif: z.boolean().optional(),
});

// Alanlar arası kurallar: engelli ise engel durumu, pasife alınıyorsa ayrılma tarihi zorunlu
function calisanKurallari(
  veri: Partial<z.infer<typeof calisanTaban>>,
  ctx: z.RefinementCtx
) {
  if (veri.engelli === true && !veri.engelDurumu?.trim()) {
    ctx.addIssue({
      code: "custom",
      path: ["engelDurumu"],
      message: "Engelli çalışan için engel durum bilgisi zorunlu",
    });
  }
  if (veri.aktif === false && !veri.istenAyrilma) {
    ctx.addIssue({
      code: "custom",
      path: ["istenAyrilma"],
      message: "Pasife alınan çalışan için işten ayrılma tarihi zorunlu",
    });
  }
}

export const calisanSemasi = calisanTaban.superRefine(calisanKurallari);
export const calisanGuncelleSemasi = calisanTaban.partial().superRefine(calisanKurallari);
// Pasife alma (DELETE) gövdesi
export const calisanPasifSemasi = z.object({ istenAyrilma: z.coerce.date() });
// Özel bilgi görüntüleme (detay) gövdesi
export const calisanDetaySemasi = z.object({ parola: z.string() });

// ---- Makine ----
export const makineDurumlari = ["calisiyor", "bakimda", "arizali"] as const;
const makineTaban = z.object({
  ad: z.string().min(1, "Makine adı zorunlu"),
  model: z.string().nullish(),
  seriNo: z.string().nullish(),
  durum: z.enum(makineDurumlari).default("calisiyor"),
  sorumluId: idNo.nullish(),
  durumNotu: z.string().nullish(), // bakımda/arızalıysa zorunlu açıklama
});

// Bakım/arıza durumuna açıklamasız geçilemez
function makineKurallari(
  veri: Partial<z.infer<typeof makineTaban>>,
  ctx: z.RefinementCtx
) {
  if (
    (veri.durum === "bakimda" || veri.durum === "arizali") &&
    !veri.durumNotu?.trim()
  ) {
    ctx.addIssue({
      code: "custom",
      path: ["durumNotu"],
      message:
        veri.durum === "arizali"
          ? "Arıza durumu için açıklama (arıza notu) zorunlu"
          : "Bakım durumu için açıklama (bakım notu) zorunlu",
    });
  }
}

export const makineSemasi = makineTaban.superRefine(makineKurallari);
export const makineGuncelleSemasi = makineTaban.partial().superRefine(makineKurallari);

// ---- Devam / puantaj ----
export const devamDurumlari = ["geldi", "gelmedi", "izinli"] as const;
export const devamSemasi = z.object({
  calisanId: idNo,
  tarih: tarihStr,
  durum: z.enum(devamDurumlari),
  girisSaat: saatStr.nullish(),
  cikisSaat: saatStr.nullish(),
});

// ---- Görev ----
export const gorevDurumlari = ["bekliyor", "devam_ediyor", "tamamlandi"] as const;
export const gorevOncelikleri = ["dusuk", "normal", "yuksek"] as const;
export const gorevSemasi = z.object({
  baslik: z.string().min(1, "Görev başlığı zorunlu"),
  aciklama: z.string().nullish(),
  calisanId: idNo.nullish(),
  makineId: idNo.nullish(),
  durum: z.enum(gorevDurumlari).default("bekliyor"),
  oncelik: z.enum(gorevOncelikleri).nullish(),
  baslangic: z.coerce.date().nullish(),
  bitis: z.coerce.date().nullish(),
});
export const gorevGuncelleSemasi = gorevSemasi.partial();
export const gorevDurumSemasi = z.object({ durum: z.enum(gorevDurumlari) });

// ---- Müşteri ----
export const musteriSemasi = z.object({
  ad: z.string().min(1, "Müşteri adı zorunlu"),
  telefon: z.string().nullish(),
  adres: z.string().nullish(),
  vergiNo: z.string().nullish(),
});
export const musteriGuncelleSemasi = musteriSemasi.partial();

// ---- Satış fırsatı ----
export const firsatDurumlari = [
  "potansiyel",
  "gorusuluyor",
  "kazanildi",
  "kaybedildi",
] as const;
export const firsatSemasi = z.object({
  musteriId: idNo,
  sorumluId: idNo.nullish(),
  baslik: z.string().nullish(),
  durum: z.enum(firsatDurumlari).default("potansiyel"),
  tutar: z.coerce.number().nonnegative().nullish(),
  tarih: z.coerce.date().nullish(),
});
export const firsatGuncelleSemasi = firsatSemasi.partial();
export const firsatDurumSemasi = z.object({ durum: z.enum(firsatDurumlari) });

// ---- Tahsilat ----
export const tahsilatDurumlari = ["bekliyor", "tahsil_edildi", "gecikti"] as const;
export const tahsilatSemasi = z.object({
  musteriId: idNo,
  satisFirsatiId: idNo.nullish(),
  tutar: z.coerce.number().positive("Tutar sıfırdan büyük olmalı"),
  vadeTarihi: z.coerce.date().nullish(),
  odemeTarihi: z.coerce.date().nullish(),
  durum: z.enum(tahsilatDurumlari).default("bekliyor"),
  odemeYontemi: z.string().nullish(),
});
export const tahsilatGuncelleSemasi = tahsilatSemasi.partial();
export const tahsilatDurumGuncelleSemasi = z.object({
  durum: z.enum(tahsilatDurumlari),
  odemeTarihi: z.coerce.date().nullish(),
  odemeYontemi: z.string().nullish(),
});

// ---- Kullanıcı yönetimi ----
const kullaniciAdi = z
  .string()
  .min(3, "Kullanıcı adı en az 3 karakter olmalı")
  .max(30, "Kullanıcı adı en fazla 30 karakter olmalı")
  .regex(/^[a-z0-9._-]+$/, "Kullanıcı adı küçük harf, rakam, nokta, tire veya alt çizgi içerebilir");
const sifreAlani = z.string().min(6, "Şifre en az 6 karakter olmalı").max(72);
export const izinSeviyeleri = ["yok", "okuma", "yazma"] as const;
// Modül anahtarları lib/yetki.ts'deki MODULLER ile aynı olmalı
export const izinHaritasiSemasi = z
  .partialRecord(
    z.enum(["calisanlar", "makineler", "devam", "gorevler", "musteriler", "tahsilatlar", "firma"]),
    z.enum(izinSeviyeleri)
  )
  .default({});

export const kullaniciSemasi = z.object({
  kullaniciAdi,
  adSoyad: z.string().min(1, "Ad soyad zorunlu"),
  sifre: sifreAlani,
  izinler: izinHaritasiSemasi,
});
export const kullaniciGuncelleSemasi = z.object({
  adSoyad: z.string().min(1).optional(),
  izinler: izinHaritasiSemasi.optional(),
  aktif: z.boolean().optional(),
  sifre: sifreAlani.optional(), // admin şifre sıfırlama
});

// Çalışanı kullanıcı olarak atama (ad soyad çalışandan alınır; onay bekler)
export const calisanKullaniciSemasi = z.object({
  kullaniciAdi,
  sifre: sifreAlani,
  izinler: izinHaritasiSemasi,
});
// Admin onay kararı
export const kullaniciOnaySemasi = z.object({
  karar: z.enum(["onayla", "reddet"]),
});

export const sifreDegistirSemasi = z.object({
  eskiSifre: z.string().min(1, "Mevcut şifre zorunlu"),
  yeniSifre: sifreAlani,
});

// ---- Süper admin: firma yönetimi ----
export const yeniFirmaSemasi = z.object({
  ad: z.string().min(1, "Firma adı zorunlu"),
  adres: z.string().nullish(),
  telefon: z.string().nullish(),
  vergiNo: z.string().nullish(),
  adminKullaniciAdi: kullaniciAdi,
  adminAdSoyad: z.string().min(1, "Admin ad soyad zorunlu"),
  adminSifre: sifreAlani,
});
export const firmaYonetimSemasi = z.object({
  aktif: z.boolean().optional(),
  ad: z.string().min(1).optional(),
});
export const sifreSifirlaSemasi = z.object({ sifre: sifreAlani });
